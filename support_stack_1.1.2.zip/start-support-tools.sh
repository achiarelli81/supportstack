#!/usr/bin/env bash

# Support Stack Start Script

# Set the path to the Docker Compose file
COMPOSE_FILE="support-compose.yml"

# Deploy the Docker stack
sudo docker stack deploy --compose-file "$COMPOSE_FILE" --detach=true support-tools 

# Check the deployment status
if [ $? -eq 0 ]; then
  echo "Docker stack deployed successfully."
else
  echo "Failed to deploy Docker stack." >&2
  exit 1
fi
