#!/usr/bin/env bash

# Support Tools Stop Stack Script

# Remove the Docker stack
sudo docker stack rm support-tools

# Check the removal status
if [ $? -eq 0 ]; then
  echo "Docker stack 'support-tools' removed successfully."
else
  echo "Failed to remove Docker stack 'support-tools'." >&2
  exit 1
fi
