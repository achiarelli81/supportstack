#!/usr/bin/env bash

# Swarm Restart Script

# Set the path to the Docker Compose file
COMPOSE_FILE="support-compose.yml"

# Set the name of the Docker stack
STACK_NAME="support-tools"

# Function to stop the Docker stack
stop_stack() {
  echo "Stopping the Docker stack: $STACK_NAME..."
  sudo docker stack rm "$STACK_NAME"

  # Wait for the stack to fully stop
  echo "Waiting for the stack to stop..."
  sleep 30  # Ensure the system has time to stop all services
}

# Function to deploy the Docker stack
deploy_stack() {
  echo "Deploying the Docker stack: $STACK_NAME..."
  sudo docker stack deploy --compose-file "$COMPOSE_FILE" --detach=true "$STACK_NAME"

  # Check the deployment status
  if [ $? -eq 0 ]; then
    echo "Docker stack deployed successfully."
  else
    echo "Failed to deploy Docker stack." >&2
    exit 1
  fi
}

# Restart the Swarm stack
echo "Restarting the Docker Swarm stack..."
stop_stack
deploy_stack

echo "Swarm restart process completed."
